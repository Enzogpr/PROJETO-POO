package com.fag.infra.celcoin;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import com.fag.domain.dto.BankslipDTO;
import com.fag.domain.repositories.IBassRepository;
import com.fag.infra.utils.JsonUtils;

public class CelcoinBassRepository implements IBassRepository{

        public static String genToken() throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        URI uri = new URI("https://sandbox.openfinance.celcoin.dev/v5/token");
        String params = "client_id=" + URLEncoder.encode("41b44ab9a56440.teste.celcoinapi.v5", StandardCharsets.UTF_8)
                + "&grant_type=" + URLEncoder.encode("client_credentials", StandardCharsets.UTF_8)
                + "&client_secret=" + URLEncoder.encode(
                        "e9d15cde33024c1494de7480e69b7a18c09d7cd25a8446839b3be82a56a044a3", StandardCharsets.UTF_8);

        HttpRequest request = HttpRequest.newBuilder(uri)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(BodyPublishers.ofString(params))
                .build();

        HttpResponse<String> response = client.send(request, BodyHandlers.ofString());

        return JsonUtils.getField(response.body(), "access_token");
    }

    @Override
    public String consultarBoleto(String linhaDigitavel) throws Exception  {

        Map<String, Object> json = JsonUtils.srtToMap(genToken());
        String token = json.get("access_token").toString();

        HttpClient client = HttpClient.newHttpClient();
    URI uri = new URI("https://sandbox.openfinance.celcoin.dev/v5/transactions/billpayments/authorize");

    String payload = "{\r\n" +
   "  \"barCode\": {\r\n" +
   "    \"type\": 0,\r\n" +
   "    \"digitable\": " +
   linhaDigitavel  +
   "  }\r\n" +
   "}";

        HttpRequest request = HttpRequest.newBuilder(uri)
        .header("Content-Type", "application/json")
        .header("Authorization", "Bearer " + token)
        .POST(BodyPublishers.ofString(payload))
        .build();

        HttpResponse<String> response = client.send(request, BodyHandlers.ofString());

        return response.body();
    }


    @Override
    public String pagarBoleto(BankslipDTO dadosBoletoConsultado) {

        try {
            System.out.println("Pagando boleto " + dadosBoletoConsultado + " na celcoin");

// Criar request de pagamento de boleto
        } catch (Exception e) {
            throw new RuntimeException("Erro ao consultar boleto");
        }

        return "";
    }

    @Override
    public String gerarQrCode(Double valorPix) {

        Map<String, Object> json = JsonUtils.srtToMap(genToken());
        String token = json.get("access_token").toString();

        return "";
    }

    
}
